package com.infosys.infytel;



import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
public class InfytelApplicationTests {

	@Test
	public void contextLoads() {
	}

}
